import unittest
from . import test_fitting

suite = unittest.TestSuite([test_fitting.suite])

double xxx(x)
double x[3];
{
  double t10;
  double t11;
  double t15;
  double t2;
  double t6;
  double t9;
  {
    t6 = a[3];
    t2 = x[2];
    t9 = a[2]*t2;
    t10 = a[0];
    t11 = x[1];
    t15 = x[0];
    return((a[5]*t2+a[1])*t2+(t6*t11+t10+t9)*t11+(a[4]*t11+t6*t15+t10+t9)*t15);
  }
}


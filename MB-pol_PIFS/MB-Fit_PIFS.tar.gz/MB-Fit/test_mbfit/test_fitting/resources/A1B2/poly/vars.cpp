
// <-> variables <->

    x[0] = @VAR@-|x-intra-A+B-1|(A1aB1a;
    x[1] = @VAR@-|x-intra-A+B-1|(A1aB2a;
    x[2] = @VAR@-|x-intra-B+B-1|(B1aB2a;

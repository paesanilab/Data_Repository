
// <-> variables <->

    x[0] = @VAR@-|x-inter-A+A-0|(A1aA2b;
    x[1] = @VAR@-|x-intra-A+B-1|(A1aB1a;
    x[2] = @VAR@-|x-intra-A+B-1|(A1aB2a;
    x[3] = @VAR@-|x-inter-A+B-0|(A1aB3b;
    x[4] = @VAR@-|x-inter-A+B-0|(A1aB4b;
    x[5] = @VAR@-|x-inter-A+B-0|(A2bB1a;
    x[6] = @VAR@-|x-inter-A+B-0|(A2bB2a;
    x[7] = @VAR@-|x-intra-A+B-1|(A2bB3b;
    x[8] = @VAR@-|x-intra-A+B-1|(A2bB4b;
    x[9] = @VAR@-|x-intra-B+B-1|(B1aB2a;
    x[10] = @VAR@-|x-inter-B+B-0|(B1aB3b;
    x[11] = @VAR@-|x-inter-B+B-0|(B1aB4b;
    x[12] = @VAR@-|x-inter-B+B-0|(B2aB3b;
    x[13] = @VAR@-|x-inter-B+B-0|(B2aB4b;
    x[14] = @VAR@-|x-intra-B+B-1|(B3bB4b;

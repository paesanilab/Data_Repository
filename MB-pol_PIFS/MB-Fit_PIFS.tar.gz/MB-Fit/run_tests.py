import test_mbfit

test_mbfit.execute_tests()

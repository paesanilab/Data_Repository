/******************************************************************************
Copyright 2019 The Regents of the University of California.
All Rights Reserved.

Permission to copy, modify and distribute any part of this Software for
educational, research and non-profit purposes, without fee, and without
a written agreement is hereby granted, provided that the above copyright
notice, this paragraph and the following three paragraphs appear in all
copies.

Those desiring to incorporate this Software into commercial products or
use for commercial purposes should contact the:
Office of Innovation & Commercialization
University of California, San Diego
9500 Gilman Drive, Mail Code 0910
La Jolla, CA 92093-0910
Ph: (858) 534-5815
FAX: (858) 534-7345
E-MAIL: invent@ucsd.edu

IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE, EVEN IF THE UNIVERSITY
OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY OF CALIFORNIA MAKES NO
REPRESENTATIONS AND EXTENDS NO WARRANTIES OF ANY KIND, EITHER IMPLIED OR
EXPRESS, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR THAT THE USE OF THE
SOFTWARE WILL NOT INFRINGE ANY PATENT, TRADEMARK OR OTHER RIGHTS.
******************************************************************************/

#ifndef CU_INCLUDE_TOOLS_READNRG_H
#define CU_INCLUDE_TOOLS_READNRG_H

#include <vector>
#include <string>
#include <stdexcept>
#include <cassert>
#include <sstream>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <algorithm>

#include "bblock/system.h"
#include "tools/custom_exceptions.h"

/**
 * @file read_nrg.h
 * @brief Contains the function declarations that allow to read an NRG file
 */

/**
 * @namespace tools
 * @brief Sets the namespace for useful tools in this software
 */
namespace tools {

/**
 * @brief Reads an NRG file
 *
 * Given the filename and a system vector to put the systems in,
 * reads all the systems, saving them in the vector in the order in
 * wich they are in the input
 * @param[in] filename Name of the file to read
 * @param[out] systems Vector of systems that will be filled with
 * the information in the file
 */
void ReadNrg(const char* filename, std::vector<bblock::System>& systems);

/**
 * @brief Reads a system inside the NRG file
 *
 * This function is called by ReadNrg, and reads one system at a time
 * @param[in] lineno Current line number of the file we are reading
 * @param[in,out] ifs Input file stream of the open file that we
 * are reading
 * @param[in,out] sys System that will be filled with
 * the information in the file
 */
void ReadSystem(size_t& lineno, std::istream& ifs, bblock::System& sys);

/**
 * @brief Reads a molecule of a system
 *
 * This function reads a molecule inside a system, and adds it to the system.
 * @param[in] lineno Current line number in the file we are reading
 * @param[in,out] ifs Input file stream of the open file that we
 * are reading
 * @param[in,out] sys System that will be filled with
 * the information in the file
 * @param[out] mon_count Number of monomers in the molecule
 */
void ReadMolecule(size_t& lineno, std::istream& ifs, bblock::System& sys, size_t& mon_count);

/**
 * @brief Reads a monomer inside a molecule
 *
 * This function reads a monomer inside a molecule, and adds it to the system.
 * @param[in] lineno Current line number in the file we are reading
 * @param[in,out] ifs Input file stream of the open file that we
 * are reading
 * @param[in,out] sys System that will be filled with
 * the information in the file
 * @param[out] mon_count Number of monomers in the molecule
 */
void ReadMonomers(size_t& lineno, std::istream& ifs, bblock::System& sys, size_t& mon_count);

}  // namespace tools

#endif  // CU_INCLUDE_TOOLS_READNRG_H

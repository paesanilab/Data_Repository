#ifndef RANDOM_ROTATION_H
#define RANDOM_ROTATION_H

#include "mt19937.h"

void random_rotation(const double*, double*);

#endif  // RANDOM_ROTATION_H

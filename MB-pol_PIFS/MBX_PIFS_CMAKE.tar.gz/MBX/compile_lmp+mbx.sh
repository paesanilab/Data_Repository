#!/bin/bash

set -e # abort if any error

./compile.sh mpi

. sourceme.sh
cd lammps/src
make clean-all; rm lmp_mpi_mbx
cp USER-MBX/fix_mbx.cpp .;cp USER-MBX/pair_mbx.cpp .;make yes-USER-MBX yes-MOLECULE yes-KSPACE yes-RIGID yes-EXTRA-PAIR yes-EXTRA-COMPUTE yes-FEP yes-MISC yes-MANYBODY yes-EXTRA-DUMP;make mpi_mbx -j 8 CXX=mpiicpc CC=mpiicc
